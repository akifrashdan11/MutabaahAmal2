package com.example.mutabaahamal;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.TextSwitcher;
import android.widget.TextView;
import android.widget.ViewSwitcher;

import com.example.mutabaahamal.Adapter.AmalanAdapter;
import com.example.mutabaahamal.Common.Common;
import com.example.mutabaahamal.Model.Amalan;
import com.getbase.floatingactionbutton.FloatingActionButton;

import it.moondroid.coverflow.components.ui.containers.FeatureCoverFlow;

public class MainActivity extends AppCompatActivity {

    FeatureCoverFlow coverFlow;
    AmalanAdapter adapter;
    TextSwitcher mTitle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        FloatingActionButton fab1 =findViewById(R.id.action1);
        FloatingActionButton fab2 =findViewById(R.id.action2);
        FloatingActionButton fab3 =findViewById(R.id.action3);
        FloatingActionButton fab4 =findViewById(R.id.action4);

        fab1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openActivity1();
            }
        });

        fab2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openActivity2();
            }
        });


        fab3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openActivity3();
            }
        });

        fab4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openActivity4();
            }
        });


        //create data
        initData();
        adapter = new AmalanAdapter(Common.amalanList,this);
        coverFlow = (FeatureCoverFlow)findViewById(R.id.coverFlow);
        mTitle = (TextSwitcher)findViewById(R.id.mtitle);
        mTitle.setFactory(new ViewSwitcher.ViewFactory() {
            @Override
            public View makeView() {
                LayoutInflater inflater = LayoutInflater.from(MainActivity.this);
                TextView text =(TextView)inflater.inflate(R.layout.layout_title,null);
                return text;
            }
        });
        coverFlow.setAdapter(adapter);
        coverFlow.setOnScrollPositionListener(new FeatureCoverFlow.OnScrollPositionListener() {
            @Override
            public void onScrolledToPosition(int position) {
                mTitle.setText(Common.amalanList.get(position).getTitle());

            }

            @Override
            public void onScrolling() {

            }
        });
        coverFlow.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                Intent intent = new Intent(MainActivity.this, AmalanDetail.class);
                intent.putExtra("amalan_index",i);
                startActivity(intent);

            }
        });


    }



    public void openActivity1(){
        Intent intent = new Intent(this,MainActivity.class);
        startActivity(intent);
    }

    public void openActivity2(){
        Intent intent = new Intent(this,Pdf.class);
        startActivity(intent);
    }

    public void openActivity3(){
        Intent intent = new Intent(this, Pdf.class);
        startActivity(intent);
    }

    public void openActivity4(){
        Intent intent = new Intent(this,Onboarding.class);
        startActivity(intent);
    }









    private void initData(){
        //Example Data
        Amalan amalan = new Amalan("Qiamullail","https://1.bp.blogspot.com/-Rs6C1adrsL4/XoM1fjmdpUI/AAAAAAAAbNU/13XuXAtp0foPcaNoMwGpSp6AbnteFQpPACLcBGAsYHQ/w945-h600-p-k-no-nu/kad%2BMA%2BQiamullail%2Blatest.png",
                "https://drive.google.com/open?id=1FGSWsmeSYOZa6Np-hyEPTcTLySSpmlVJ");
        Common.amalanList.add(amalan);

        amalan = new Amalan("Solat Dhuha","https://1.bp.blogspot.com/-Rs6C1adrsL4/XoM1fjmdpUI/AAAAAAAAbNU/13XuXAtp0foPcaNoMwGpSp6AbnteFQpPACLcBGAsYHQ/w945-h600-p-k-no-nu/kad%2BMA%2BQiamullail%2Blatest.png",
                "https://drive.google.com/open?id=1FGSWsmeSYOZa6Np-hyEPTcTLySSpmlVJ");
        Common.amalanList.add(amalan);

        amalan = new Amalan("Terawih","https://1.bp.blogspot.com/-Rs6C1adrsL4/XoM1fjmdpUI/AAAAAAAAbNU/13XuXAtp0foPcaNoMwGpSp6AbnteFQpPACLcBGAsYHQ/w945-h600-p-k-no-nu/kad%2BMA%2BQiamullail%2Blatest.png",
                "https://drive.google.com/open?id=1FGSWsmeSYOZa6Np-hyEPTcTLySSpmlVJ");
        Common.amalanList.add(amalan);

        amalan = new Amalan("Al-Mulk","https://1.bp.blogspot.com/-Rs6C1adrsL4/XoM1fjmdpUI/AAAAAAAAbNU/13XuXAtp0foPcaNoMwGpSp6AbnteFQpPACLcBGAsYHQ/w945-h600-p-k-no-nu/kad%2BMA%2BQiamullail%2Blatest.png",
                "https://drive.google.com/open?id=1FGSWsmeSYOZa6Np-hyEPTcTLySSpmlVJ");
        Common.amalanList.add(amalan);

        amalan = new Amalan("Tidur","https://1.bp.blogspot.com/-Rs6C1adrsL4/XoM1fjmdpUI/AAAAAAAAbNU/13XuXAtp0foPcaNoMwGpSp6AbnteFQpPACLcBGAsYHQ/w945-h600-p-k-no-nu/kad%2BMA%2BQiamullail%2Blatest.png",
                "https://drive.google.com/open?id=1FGSWsmeSYOZa6Np-hyEPTcTLySSpmlVJ");
        Common.amalanList.add(amalan);


    }

}
