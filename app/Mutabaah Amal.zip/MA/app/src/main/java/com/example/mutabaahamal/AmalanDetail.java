package com.example.mutabaahamal;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import com.example.mutabaahamal.Common.Common;
import com.example.mutabaahamal.Model.Amalan;
import com.flaviofaria.kenburnsview.KenBurnsView;
import com.squareup.picasso.Picasso;

public class AmalanDetail extends AppCompatActivity {

    KenBurnsView amalan_image;
    TextView amalan_title,amalan_summary;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_amalan_detail);

        amalan_image=(KenBurnsView)findViewById(R.id.amalan_image);
        amalan_title=(TextView)findViewById(R.id.amalan_title);
        amalan_summary=(TextView)findViewById(R.id.amalan_summary);

        if(getIntent()!=null){
            int amalan_index = getIntent().getIntExtra("amalan_index",-1);
            if(amalan_index != -1)
                loadAmalanDetail(amalan_index);
        }


    }

    private void loadAmalanDetail(int index) {
        Amalan amalan= Common.amalanList.get(index);

        //Load image dekat summary

        Picasso.with(getBaseContext()).load(amalan.getUrl()).into(amalan_image);
        amalan_title.setText(amalan.getTitle());
        amalan_summary.setText(amalan.getSummary());


    }
}
