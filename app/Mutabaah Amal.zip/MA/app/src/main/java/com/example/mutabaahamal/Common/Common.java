package com.example.mutabaahamal.Common;

import com.example.mutabaahamal.Model.Amalan;

import java.util.ArrayList;
import java.util.List;

public class Common {

    public static List<Amalan> amalanList = new ArrayList<>();
}
